import logging
import sys
import traceback
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.database import create_pool, close_pool
from app.routers import (
    profiles, courses, questions, quizzes,
    attempts, analytics, announcements, messages, admin, auth,teachers_dashboard, syllabus_to_quiz
)
from app.routers import ai_quiz


# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s  %(levelname)-8s  %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
# Quieten noisy asyncpg logs
logging.getLogger("asyncpg").setLevel(logging.WARNING)
logger = logging.getLogger("quiz")

settings = get_settings()


# ── Lifespan ─────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=" * 60)
    logger.info("  🎓  Quiz Platform API  —  DEV MODE")
    logger.info("  ENV:      %s", settings.app_env)
    logger.info("  DEBUG:    %s", settings.debug)
    logger.info("  ORIGINS:  %s", settings.allowed_origins)
    logger.info("=" * 60)
    await create_pool()
    yield
    await close_pool()
    logger.info("Shutdown complete.")


# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Quiz Platform API  [DEV]",
    description=(
        "College quiz/test platform – admin · teacher · HOD · student.\n\n"
        "**Dev mode:** full error traces, open CORS, debug logging.\n\n"
        "📌 All routes are prefixed `/api/v1`"
    ),
    version="1.0.0-dev",
    debug=True,           # shows full Python tracebacks in /docs error responses
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── CORS – open in dev ────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"], # Your React URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Dev error handler – return full traceback in JSON ─────────────────────────
@app.exception_handler(Exception)
async def dev_exception_handler(request: Request, exc: Exception):
    tb = traceback.format_exc()
    logger.error("Unhandled exception on %s %s\n%s", request.method, request.url.path, tb)
    return JSONResponse(
        status_code=500,
        content={
            "detail": str(exc),
            "type": type(exc).__name__,
            "traceback": tb.splitlines(),   # handy for Postman / curl dev
        },
    )


# ── Request logger ────────────────────────────────────────────────────────────
import time

@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    ms = (time.perf_counter() - start) * 1000
    logger.debug("%-6s %-40s  %s  %.0fms",
                 request.method, request.url.path, response.status_code, ms)
    return response


# ── Routers ───────────────────────────────────────────────────────────────────
PREFIX = "/api/v1"

app.include_router(auth.router,          prefix=PREFIX)
app.include_router(profiles.router,      prefix=PREFIX)
app.include_router(courses.router,       prefix=PREFIX)
app.include_router(questions.router,     prefix=PREFIX)
app.include_router(quizzes.router,       prefix=PREFIX)
app.include_router(attempts.router,      prefix=PREFIX)
app.include_router(analytics.router,     prefix=PREFIX)
app.include_router(announcements.router, prefix=PREFIX)
app.include_router(messages.router,      prefix=PREFIX)
app.include_router(admin.router,         prefix=PREFIX)
app.include_router(teachers_dashboard.router,         prefix=PREFIX)
app.include_router(syllabus_to_quiz.router,         prefix=PREFIX)
# 
app.include_router(ai_quiz.router, prefix=PREFIX)
# teachers_dashboard


# ── Health / root ─────────────────────────────────────────────────────────────
@app.get("/health", tags=["Dev"])
async def health():
    return {"status": "ok", "env": settings.app_env, "debug": settings.debug}


@app.get("/", tags=["Dev"])
async def root():
    return {
        "message": "Quiz Platform API – Dev Mode",
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health",
    }

