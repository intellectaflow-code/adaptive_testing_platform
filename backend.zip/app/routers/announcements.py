from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
import asyncpg

from app.database import get_db
from app.dependencies import get_current_user, require_teacher_up
from app.schemas.messaging import AnnouncementCreate, AnnouncementUpdate, AnnouncementOut

router = APIRouter(prefix="/announcements", tags=["Announcements"])


@router.post("", response_model=AnnouncementOut, status_code=201)
async def create_announcement(
    body: AnnouncementCreate,
    current_user: dict = Depends(require_teacher_up),
    db: asyncpg.Connection = Depends(get_db),
):
    row = await db.fetchrow(
        """
        INSERT INTO public.announcements (course_id, created_by, title, message)
        VALUES ($1, $2, $3, $4) RETURNING *
        """,
        str(body.course_id) if body.course_id else None,
        str(current_user["id"]), body.title, body.message,
    )
    return dict(row)


@router.get("", response_model=List[AnnouncementOut])
async def list_announcements(
    course_id: Optional[str] = Query(None),
    active_only: bool = Query(True),
    skip: int = 0,
    limit: int = 50,
    current_user: dict = Depends(get_current_user),
    db: asyncpg.Connection = Depends(get_db),
):
    where_parts = ["1=1"]
    params: list = []
    idx = 1

    if current_user["role"] == "student":
        # Only see announcements for their courses
        if course_id:
            where_parts.append(f"course_id = ${idx}"); params.append(course_id); idx += 1
        else:
            where_parts.append(
                f"""(course_id IN (
                    SELECT course_id FROM public.enrollments WHERE student_id = ${idx}
                ) OR course_id IS NULL)"""
            )
            params.append(str(current_user["id"])); idx += 1
    else:
        if course_id:
            where_parts.append(f"course_id = ${idx}"); params.append(course_id); idx += 1

    if active_only:
        where_parts.append("is_active = true")

    where = " AND ".join(where_parts)
    rows = await db.fetch(
        f"SELECT * FROM public.announcements WHERE {where} ORDER BY created_at DESC LIMIT ${idx} OFFSET ${idx+1}",
        *params, limit, skip,
    )
    return [dict(r) for r in rows]


@router.get("/{announcement_id}", response_model=AnnouncementOut)
async def get_announcement(
    announcement_id: str,
    _: dict = Depends(get_current_user),
    db: asyncpg.Connection = Depends(get_db),
):
    row = await db.fetchrow(
        "SELECT * FROM public.announcements WHERE id = $1", announcement_id
    )
    if not row:
        raise HTTPException(status_code=404, detail="Announcement not found")
    return dict(row)


@router.put("/{announcement_id}", response_model=AnnouncementOut)
async def update_announcement(
    announcement_id: str,
    body: AnnouncementUpdate,
    current_user: dict = Depends(require_teacher_up),
    db: asyncpg.Connection = Depends(get_db),
):
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    set_clause = ", ".join(f"{k} = ${i+2}" for i, k in enumerate(updates.keys()))
    row = await db.fetchrow(
        f"UPDATE public.announcements SET {set_clause} WHERE id = $1 AND created_by = ${len(updates)+2} RETURNING *",
        announcement_id, *updates.values(), str(current_user["id"]),
    )
    if not row:
        raise HTTPException(status_code=404, detail="Announcement not found or not your announcement")
    return dict(row)


@router.delete("/{announcement_id}", status_code=204)
async def delete_announcement(
    announcement_id: str,
    current_user: dict = Depends(require_teacher_up),
    db: asyncpg.Connection = Depends(get_db),
):
    await db.execute(
        "DELETE FROM public.announcements WHERE id = $1 AND created_by = $2",
        announcement_id, str(current_user["id"]),
    )

